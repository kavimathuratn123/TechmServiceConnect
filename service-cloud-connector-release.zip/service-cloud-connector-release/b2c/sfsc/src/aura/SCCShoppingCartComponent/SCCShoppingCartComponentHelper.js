({
	openShoppingCartHelper : function() {
		
	}
})